$(document).ready(function(){

  console.debug('Apply JS here');

});